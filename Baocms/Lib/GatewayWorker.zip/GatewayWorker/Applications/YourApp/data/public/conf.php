<?php 
 if(!defined('LMXCMS')){exit();} 
 //本文件为缓存文件 无需手动更改
 return array (
  'default_temdir' => 'default',
  'mobile_temdir' => 'wap',
  'user_pwd_key' => '1409414669',
  'weburl' => '/',
  'global' => 
  array (
    'webname_public' => '-安阳市瑞明科技创业有限公司',
    'icp' => '豫icp备',
    'address' => '安阳市高新区平原路与海河大道交叉口西南角',
    'phone' => '400-838-0120',
    'download_notice' => '修改后台 扩展变量',
    'nav_top' => '336,335',
  ),
  'globalType' => 
  array (
    'webname_public' => '1',
    'icp' => '1',
    'address' => '1',
    'phone' => '1',
    'download_notice' => '1',
    'nav_top' => '1',
  ),
  'webname' => '微标客',
  'keywords' => '微标客',
  'description' => '微标客',
  'ishtml' => 0,
  'searchtime' => 5,
  'navsplit' => '>',
  'isbook' => 1,
  'repeatbook' => 20,
  'issmall' => 1,
  'iswater' => 0,
  'small_width' => 270,
  'small_height' => 195,
  'markImg' => '/file/mark/mark.png',
  'tuijianSelect' => '一级推荐
二级推荐
三级推荐
四级推荐
五级推荐
六级推荐
七级推荐
八级推荐
九级推荐
十级推荐',
  'remenSelect' => '一级热门
二级热门
三级热门
四级热门
五级热门
六级热门
七级热门
八级热门
九级热门
十级热门',
  'bookDisplay' => 1,
  'booknum' => 10,
  'searchnum' => 10,
  'login_mark' => 317529,
  'isbookdata' => 1,
  'version' => '1.4',
  'upload_file_pre' => 
  array (
    0 => 'rar',
    1 => 'zip',
    2 => 'xls',
  ),
  'upload_image_pre' => 
  array (
    0 => 'jpg',
    1 => 'gif',
    2 => 'png',
    3 => 'jpeg',
  ),
  'update_max_size' => 80,
  'q_upload_file_pre' => 
  array (
    0 => 'rar',
    1 => 'zip',
    2 => 'jpg',
    3 => 'gif',
    4 => 'png',
    5 => 'xls',
  ),
  'q_update_max_size' => 2,
  'is_search' => 1,
  'is_ip' => 0,
  'ip_list' => '',
  'contentkey' => '#####http://www.taoleyizhan.com#####0',
  'is_check_description' => 0,
  'is_content_key' => 0,
  'is_title_key' => 0,
) 
?>