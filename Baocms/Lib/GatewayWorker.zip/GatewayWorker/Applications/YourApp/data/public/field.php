<?php 
 if(!defined('LMXCMS')){exit();} 
 //本文件为缓存文件 无需手动更改
 return array (
  3 => 
  array (
    11 => 
    array (
      'fid' => '11',
      'mid' => '3',
      'fname' => 'pic',
      'ftitle' => '缩略图',
      'ftype' => 'image',
      'ismust' => '1',
      'sort' => '3',
      'defaults' => '',
      'vice' => '0',
    ),
    24 => 
    array (
      'fid' => '24',
      'mid' => '3',
      'fname' => 'xpic',
      'ftitle' => '效果图',
      'ftype' => 'image',
      'ismust' => '1',
      'sort' => '2',
      'defaults' => '',
      'vice' => '0',
    ),
    23 => 
    array (
      'fid' => '23',
      'mid' => '3',
      'fname' => 'file',
      'ftitle' => '上传文件',
      'ftype' => 'file',
      'ismust' => '0',
      'sort' => '1',
      'defaults' => '',
      'vice' => '0',
    ),
    28 => 
    array (
      'fid' => '28',
      'mid' => '3',
      'fname' => 'puber',
      'ftitle' => '发布人',
      'ftype' => 'text',
      'ismust' => '1',
      'sort' => '0',
      'defaults' => '0',
      'vice' => '0',
    ),
    27 => 
    array (
      'fid' => '27',
      'mid' => '3',
      'fname' => 'format',
      'ftitle' => '格式',
      'ftype' => 'text',
      'ismust' => '0',
      'sort' => '0',
      'defaults' => '',
      'vice' => '0',
    ),
    26 => 
    array (
      'fid' => '26',
      'mid' => '3',
      'fname' => 'state',
      'ftitle' => '文章状态',
      'ftype' => 'selects',
      'ismust' => '0',
      'sort' => '0',
      'defaults' => '已发布==1
审核中==0',
      'vice' => '0',
    ),
    19 => 
    array (
      'fid' => '19',
      'mid' => '3',
      'fname' => 'sort',
      'ftitle' => '排序',
      'ftype' => 'text',
      'ismust' => '0',
      'sort' => '0',
      'defaults' => '0',
      'vice' => '0',
    ),
    5 => 
    array (
      'fid' => '5',
      'mid' => '3',
      'fname' => 'content',
      'ftitle' => '正文',
      'ftype' => 'editor',
      'ismust' => '0',
      'sort' => '0',
      'defaults' => '',
      'vice' => '1',
    ),
  ),
  1 => 
  array (
    3 => 
    array (
      'fid' => '3',
      'mid' => '1',
      'fname' => 'pic',
      'ftitle' => '产品图片',
      'ftype' => 'image',
      'ismust' => '0',
      'sort' => '2',
      'defaults' => '',
      'vice' => '0',
    ),
    4 => 
    array (
      'fid' => '4',
      'mid' => '1',
      'fname' => 'duotp',
      'ftitle' => '产品图片集',
      'ftype' => 'moreimage',
      'ismust' => '0',
      'sort' => '1',
      'defaults' => '',
      'vice' => '0',
    ),
    29 => 
    array (
      'fid' => '29',
      'mid' => '1',
      'fname' => 'video',
      'ftitle' => '视频地址',
      'ftype' => 'text',
      'ismust' => '0',
      'sort' => '0',
      'defaults' => '',
      'vice' => '0',
    ),
    13 => 
    array (
      'fid' => '13',
      'mid' => '1',
      'fname' => 'sort',
      'ftitle' => '排序',
      'ftype' => 'text',
      'ismust' => '0',
      'sort' => '0',
      'defaults' => '0',
      'vice' => '0',
    ),
    1 => 
    array (
      'fid' => '1',
      'mid' => '1',
      'fname' => 'content',
      'ftitle' => '正文',
      'ftype' => 'editor',
      'ismust' => '0',
      'sort' => '0',
      'defaults' => '',
      'vice' => '1',
    ),
  ),
  4 => 
  array (
    41 => 
    array (
      'fid' => '41',
      'mid' => '4',
      'fname' => 'pic',
      'ftitle' => '封面图',
      'ftype' => 'image',
      'ismust' => '0',
      'sort' => '0',
      'defaults' => '',
      'vice' => '0',
    ),
    40 => 
    array (
      'fid' => '40',
      'mid' => '4',
      'fname' => 'state',
      'ftitle' => '审核状态',
      'ftype' => 'selects',
      'ismust' => '0',
      'sort' => '0',
      'defaults' => '审核中==0
审核通过==1
成功项目==2
未通过==-1',
      'vice' => '0',
    ),
    39 => 
    array (
      'fid' => '39',
      'mid' => '4',
      'fname' => 'bider',
      'ftitle' => '中标人',
      'ftype' => 'text',
      'ismust' => '0',
      'sort' => '0',
      'defaults' => '',
      'vice' => '0',
    ),
    38 => 
    array (
      'fid' => '38',
      'mid' => '4',
      'fname' => 'garget',
      'ftitle' => '目标金额',
      'ftype' => 'text',
      'ismust' => '0',
      'sort' => '0',
      'defaults' => '',
      'vice' => '0',
    ),
    37 => 
    array (
      'fid' => '37',
      'mid' => '4',
      'fname' => 'file',
      'ftitle' => '文件上传',
      'ftype' => 'file',
      'ismust' => '0',
      'sort' => '0',
      'defaults' => '',
      'vice' => '0',
    ),
    36 => 
    array (
      'fid' => '36',
      'mid' => '4',
      'fname' => 'publisher',
      'ftitle' => '发布人',
      'ftype' => 'text',
      'ismust' => '0',
      'sort' => '0',
      'defaults' => '',
      'vice' => '0',
    ),
    34 => 
    array (
      'fid' => '34',
      'mid' => '4',
      'fname' => 'sort',
      'ftitle' => '排序',
      'ftype' => 'text',
      'ismust' => '0',
      'sort' => '0',
      'defaults' => '',
      'vice' => '0',
    ),
    33 => 
    array (
      'fid' => '33',
      'mid' => '4',
      'fname' => 'overtime',
      'ftitle' => '截止日期',
      'ftype' => 'date',
      'ismust' => '0',
      'sort' => '0',
      'defaults' => '',
      'vice' => '0',
    ),
    32 => 
    array (
      'fid' => '32',
      'mid' => '4',
      'fname' => 'address',
      'ftitle' => '施工地址',
      'ftype' => 'text',
      'ismust' => '0',
      'sort' => '0',
      'defaults' => '',
      'vice' => '0',
    ),
    31 => 
    array (
      'fid' => '31',
      'mid' => '4',
      'fname' => 'project',
      'ftitle' => '项目名称',
      'ftype' => 'text',
      'ismust' => '0',
      'sort' => '0',
      'defaults' => '',
      'vice' => '0',
    ),
    30 => 
    array (
      'fid' => '30',
      'mid' => '4',
      'fname' => 'content',
      'ftitle' => '正文',
      'ftype' => 'editor',
      'ismust' => '0',
      'sort' => '0',
      'defaults' => '',
      'vice' => '1',
    ),
  ),
  2 => 
  array (
    12 => 
    array (
      'fid' => '12',
      'mid' => '2',
      'fname' => 'sort',
      'ftitle' => '排序',
      'ftype' => 'text',
      'ismust' => '0',
      'sort' => '0',
      'defaults' => '0',
      'vice' => '0',
    ),
    6 => 
    array (
      'fid' => '6',
      'mid' => '2',
      'fname' => 'pic',
      'ftitle' => '新闻图片',
      'ftype' => 'image',
      'ismust' => '0',
      'sort' => '0',
      'defaults' => '',
      'vice' => '0',
    ),
    2 => 
    array (
      'fid' => '2',
      'mid' => '2',
      'fname' => 'content',
      'ftitle' => '正文',
      'ftype' => 'editor',
      'ismust' => '0',
      'sort' => '0',
      'defaults' => '',
      'vice' => '1',
    ),
  ),
) 
?>