<?php 
 if(!defined('LMXCMS')){exit();} 
 //本文件为缓存文件 无需手动更改
 return array (
  1 => 
  array (
    'mid' => '1',
    'mname' => '产品模型',
    'tab' => 'product_data',
    'content' => '',
  ),
  2 => 
  array (
    'mid' => '2',
    'mname' => '新闻模型',
    'tab' => 'news_data',
    'content' => '',
  ),
  3 => 
  array (
    'mid' => '3',
    'mname' => '素材模型',
    'tab' => 'mingshi_data',
    'content' => '素材模型',
  ),
  4 => 
  array (
    'mid' => '4',
    'mname' => '投标模型',
    'tab' => 'tender_data',
    'content' => '',
  ),
) 
?>