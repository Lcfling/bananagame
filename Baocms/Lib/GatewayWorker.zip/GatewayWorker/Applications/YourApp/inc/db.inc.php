<?php 

/**

 *  【梦想cms】 http://www.lmxcms.com

 * 

 *   数据库配置文件

 */

defined('LMXCMS') or exit();

define('DB_HOST','localhost'); //数据库地址

define('DB_NAME','dmx');   //数据库名字

define('DB_USER','dmx');      //数据库用户名

define('DB_PWD','lcf2954626');          //数据库密码

define('DB_PORT','');          //mysql端口号

define('DB_CHAR','UTF8');      //数据库编码

define('DB_PRE','lmx_');       //数据库前缀

?>